import requests
import logging
import time

from selenium import webdriver

from pages.quotes_page import QuotesPage

logging.basicConfig(format='%(asctime)s %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',datefmt='%d-%m-%Y %H:%M:%S',level=logging.INFO,filename='logs.txt')

logger = logging.getLogger('covid_scheduling')

def CheckMessage():
    page_content = requests.get('https://www.unchealthcare.org/coronavirus/vaccines/phase-1b-covid-19-vaccine/').content
    page = QuotesPage(page_content)
    if page.quotes[0] == None:
        message = ''
    else:
        message = page.quotes[0].content

    if "We’re very sorry" in message:
        logger.info(f"Answer was : `{message}`")
        return False
    else:
        logger.info('THERE ARE APPOINTMENTS AVAILABLE!!!!!')
        return True

result = CheckMessage()

while result == False:
    time.sleep(10*60)
    result = CheckMessage()

chrome = webdriver.Chrome(executable_path='/home/doug/PycharmProjects/quote_scraper/chromedriver')
chrome.get('http://74.136.132.35/MUSIC/RHAPSODY/R/Rick%20Astley/Whenever%20You%20Need%20Somebody/01%20-%20Never%20Gonna%20Give%20You%20Up(1).mp3')
