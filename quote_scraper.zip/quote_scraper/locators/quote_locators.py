class QuoteLocators:
    CONTENT = 'h3'
