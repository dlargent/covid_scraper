class QuotesPageLocators:
    QUOTE = 'div.cmsPageContent'