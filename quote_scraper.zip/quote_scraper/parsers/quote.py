from locators.quote_locators import QuoteLocators

class QuoteParser:
    """
    Given on of the specific quote divs, find out the data about
    the quote (content, author, tags)
    """
    def __init__(self, parent):
        self.parent = parent

    def __repr__(self):
        return f'<Quote {self.content} by {self.author}>'

    @property
    def content(self):
        locator = QuoteLocators.CONTENT
        if self.parent.select_one(locator) == None:
            return ''
        else:
            return self.parent.select_one(locator).string